# Zero Zero

A sustainability app that helps users save money, reduce their carbon footprint, and improve well-being through real-time data and AI-powered insights.

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🔧 Environment Setup

Create a `.env` file in the root directory:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_WATER_API_URL=https://www.waterqualitydata.us/data/Result/search
```

## 📦 Tech Stack

- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite 5.0.8 ✅
- **Styling**: Tailwind CSS + Custom CSS Variables
- **Backend**: Supabase v2.46.0 ✅ (EINTEGRITY Fixed)
- **Animation**: Framer Motion
- **Deployment**: Netlify

## 🔧 EINTEGRITY DEPLOYMENT ERRORS - ALL FIXED ✅

### ❌ **Previous Error:**
```
npm ERR! Integrity check failed for @supabase/supabase-js@2.39.0
npm ERR! Expected: sha512-xxx
npm ERR! Actual: sha512-yyy
```

### ✅ **Solution Applied:**

**1. Updated to Clean Supabase Packages:**
```json
{
  "@supabase/supabase-js": "^2.46.0",
  "@supabase/storage-js": "^2.8.0", 
  "@supabase/postgrest-js": "^1.17.0"
}
```

**2. Regenerated package-lock.json:**
- All packages now use clean NPM registry URLs
- Fresh integrity checksums generated
- No more corrupted tarball references

**3. Fixed Netlify Build Configuration:**
```toml
[build]
command = "npm install && npm run build"
publish = "dist"

[build.environment]
NODE_VERSION = "18"
NPM_VERSION = "8.19.4"
```

**4. Cleaned File Structure:**
- Removed duplicate `src/` directory conflicts
- Root-level organization (no nested structures)
- TypeScript configured for clean compilation

## 🚀 Deployment - GitHub → Netlify

### ✅ **All Deployment Errors Fixed**

Run verification to confirm all fixes:
```bash
npm run deploy-ready
```

### 📋 **Deployment Steps**

**1. Commit Clean Packages:**
```bash
git add .
git commit -m "Fix: Resolve EINTEGRITY errors with clean Supabase packages"
git push origin main
```

**2. Netlify Configuration:**
- **Repository**: `https://github.com/00app/zero-zero-app`
- **Branch**: `main`
- **Build Command**: `npm install && npm run build` ✅
- **Publish Directory**: `dist` ✅
- **Node Version**: 18 ✅
- **npm Version**: 8.19.4 ✅

**3. Clear Netlify Cache:**
Go to Netlify dashboard → **"Clear cache and deploy site"**

**4. Environment Variables (Set in Netlify Dashboard):**
```env
VITE_SUPABASE_URL=your-supabase-project-url
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
```

### 🐛 **Deployment Errors - ALL RESOLVED**

| Error Type | Status | Solution |
|------------|---------|----------|
| `EINTEGRITY checksum mismatch` | ✅ **FIXED** | Updated to Supabase v2.46.0 with clean NPM registry |
| `corrupted tarball URLs` | ✅ **FIXED** | Regenerated package-lock.json with fresh checksums |
| `duplicate src/ conflicts` | ✅ **FIXED** | Removed conflicting directory structure |
| `missing lockfile` | ✅ **FIXED** | package-lock.json properly tracked in Git |
| `Node.js version mismatch` | ✅ **FIXED** | Netlify configured for Node.js 18 |
| `TypeScript compilation errors` | ✅ **FIXED** | Clean tsconfig.json with proper exclusions |

## 🎨 Design System

Zero Zero follows a strict brutalist design aesthetic:

- **Colors**: Black (#000000), White (#FFFFFF), Grey (#242424) only
- **Typography**: 3-level hierarchy (24px/16px/12px) with Roboto font
- **Spacing**: 8px grid system
- **No shadows, gradients, or decorative elements**

## 📱 Features

- **Intro Animation**: Cinematic glitch effect with RSVP-style text
- **Onboarding Flow**: 7-step data collection with UK English support
- **Dashboard**: Interactive module system with expandable cards
- **Carbon Calculations**: Real-time environmental impact tracking
- **AI Chat**: Personalized sustainability recommendations
- **Dark/Light Mode**: Theme switching with persistent preferences
- **Mobile-First**: Responsive design optimized for all devices

## 🌍 Localization

- UK English throughout (colour, realise, programme, etc.)
- Support for UK postcodes and US zip codes
- Currency displayed in GBP
- "Flat" instead of "apartment" terminology

## 🔧 Development

### Prerequisites

- Node.js 18 (specified in .nvmrc)
- npm 8.19.4 or higher
- Clean package-lock.json (no integrity errors)

### Installation

```bash
# Clone the repository
git clone https://github.com/00app/zero-zero-app.git

# Navigate to project directory
cd zero-zero-app

# Install dependencies (with clean checksums)
npm install

# Start development server
npm run dev
```

### Build Process

```bash
# Type checking
npm run type-check

# Clean build
npm run clean

# Production build (includes type checking)
npm run build

# Preview production build
npm run preview

# Comprehensive deployment verification
npm run deploy-ready
```

## 🔐 Supabase Integration - EINTEGRITY Fixed

### **Clean Package Versions:**
- **@supabase/supabase-js**: v2.46.0 (latest stable with security patches)
- **@supabase/storage-js**: v2.8.0 (clean NPM registry)
- **@supabase/postgrest-js**: v1.17.0 (fresh checksums)

### **Features:**
- Authentication with email/password
- Real-time database updates
- File storage and management
- Edge functions for serverless logic
- Full TypeScript support

### **Security:**
- Latest vulnerability fixes included
- Clean dependency tree without conflicts
- Proper environment variable configuration

## 📊 Build Performance

**Optimizations Applied:**
- Tree shaking for smaller bundles
- Code splitting with manual chunks
- Asset optimization with Terser
- Clean dependency resolution (no integrity errors)
- TypeScript strict mode

**Performance Targets:**
- Lighthouse Score: 90+
- First Contentful Paint: <2s
- Time to Interactive: <3s
- Build Size: <1MB gzipped

## 🔧 Build Commands

```bash
# Development
npm run dev          # Start dev server (port 3000)
npm run build        # Build for production
npm run preview      # Preview production build

# Quality Assurance
npm run type-check   # TypeScript validation
npm run lint         # TypeScript linting
npm run verify       # Comprehensive verification
npm run deploy-ready # Full deployment check (EINTEGRITY + all fixes)

# Maintenance
npm run clean        # Clean build directory and corrupted packages
```

## 🛠️ Troubleshooting

### EINTEGRITY Errors Fixed ✅

**Previous Issues:**
- Corrupted Supabase package checksums
- Integrity mismatches during npm install
- Build failures on Netlify

**Solutions Applied:**
- Updated all Supabase packages to latest stable versions
- Regenerated package-lock.json with fresh checksums
- Ensured all packages use clean NPM registry URLs
- Configured Netlify to clear cache on deployment

### Common Issues & Solutions

**Build Failures:**
- Run `npm run deploy-ready` to verify all requirements
- Clear npm cache: `npm cache clean --force`
- Remove node_modules and reinstall: `npm run clean && npm install`

**Type Errors:**
- Run `npm run type-check` for detailed errors
- Ensure TypeScript excludes duplicate directories

**Environment Issues:**
- Copy .env.example to .env
- Verify all VITE_ prefixed variables
- Check Netlify environment configuration

## 📄 License

MIT License - see LICENSE file for details

---

## 🎯 **DEPLOYMENT STATUS: ALL ERRORS FIXED ✅**

### 🟢 **EINTEGRITY Issues Resolved:**
- ✅ Clean Supabase packages (v2.46.0) from NPM registry
- ✅ Fresh package-lock.json with verified checksums
- ✅ No more corrupted tarball references
- ✅ All dependencies use stable, maintained versions

### 🟢 **GitHub → Netlify Integration:**
- ✅ Repository: https://github.com/00app/zero-zero-app
- ✅ Build command optimized for Netlify
- ✅ Node.js 18 with npm 8.19.4 configured
- ✅ Environment variables documented
- ✅ Cache clearing enabled

### 🟢 **Production Ready:**
- ✅ TypeScript compilation without errors
- ✅ Clean file structure (no duplicates)
- ✅ Responsive design with brutalist aesthetic
- ✅ Supabase authentication and database integration
- ✅ Performance optimized build process

**The app is now ready for seamless deployment without any EINTEGRITY or checksum errors!**

Visit the app at `http://localhost:3000` to start developing.

For deployment, simply push to the main branch and Netlify will automatically build and deploy with the clean package configuration.